import { useReducer } from "react";
import { useContext } from "react";
import { createContext } from "react";
import reducer from "../reducer/taskReducer";

const initialState = {
    tasks: [
        {
            id: 1,
            title:"first task",
            description: 'eat apple',
            time: "01:22:20"
        },
        {
            id: 2,
            title:"second task",
            description: 'read book',
            time: "05:32:23"
        },
    ]
}

const taskStateContext = createContext()
const taskDispatchContext= createContext();

export const useTaskState = () => useContext(taskStateContext);
export const useTaskDispatch = () => useContext(taskDispatchContext)

export default function StopWatchProvider({children}){
    const [state, dispatch] = useReducer(reducer,initialState);

    return(
        <taskStateContext.Provider value ={state}>
            <taskDispatchContext.Provider value={dispatch}>
                {children}
            </taskDispatchContext.Provider>
        </taskStateContext.Provider>
    )
}

