import { useState, useEffect } from "react";
import Tasks from "./component/Tasks.js";
import TaskForm from "./component/TaskForm.js";
const Stopwatch = () => {
    const [time, setTime] = useState(0);
    const [running, setRunning] = useState(false);
    const [isVisible, setIsVisible] = useState(false)
    const [isdisable, setIsDisable] = useState("")
    useEffect(() => {
      let interval;
      if (running) {
        interval = setInterval(() => {
          setTime((prevTime) => prevTime + 10);
        }, 10);
      } else if (!running) {
        clearInterval(interval);
      }
      return () => clearInterval(interval);
     
    }, [running]);
    let hour = ("0" + Math.floor((time / 60000) % 60)).slice(-2)
    let minuts = ("0" + Math.floor((time / 1000) % 60)).slice(-2)
    let seconds = ("0" + ((time / 10) % 100)).slice(-2)
    let dispTime = `${hour}: ${minuts}: ${seconds}`
    return (
       
      <div className="stopwatch">
        <div className="numbers">
          <span>{hour}:</span>
          <span>{minuts}:</span>
          <span>{seconds}</span>
        </div>
        <div className="buttons">
        <button onClick={() => { setRunning(true); setIsDisable("start"); }} disabled={isdisable === "start"}>
          Start
        </button>
        <button onClick={() => { setRunning(false); setIsDisable("stop"); }} disabled={isdisable === "stop"}>
          Stop
        </button>
        <button onClick={() => { setIsVisible(true) }} >save</button>
        </div>
        {isVisible && <TaskForm  dispTime={ dispTime } setIsVisible={setIsVisible} setTime={setTime}/>}
        <Tasks/>
      </div>
    );
  };


export default Stopwatch