import './App.css';
import Stopwatch from './Stopwatch'
import TaskProvider from './context/context'
function App() {
  return (
    <TaskProvider>
    <Stopwatch />
    </TaskProvider>

  );
}

export default App;
