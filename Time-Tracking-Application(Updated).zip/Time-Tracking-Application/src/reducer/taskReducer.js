import { v4 as uuid } from "uuid";

function reducer(state, {type, newTitle, newDescription, newTime,editedTitle,editedDescription,id}) {
    switch (type) {
        case 'SAVE':
            return {
                ...state,
                tasks: [
                    ...state.tasks,
                    {
                        id: uuid(),
                        title: newTitle,
                        description: newDescription,
                        time: newTime
                    }
                ]
                
            };
            case "EDIT":
                return {
                  ...state,
                  tasks: state.tasks.map((task) =>
                    task.id === id ? { ...task, title:editedTitle,description:editedDescription } : task
                  ),
                };
        default:
            throw new Error("Action unkonwn")
    }
}

export default reducer;