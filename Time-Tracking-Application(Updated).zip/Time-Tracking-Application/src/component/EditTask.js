import useInputState from "../hooks/useInputState";
import { useTaskDispatch } from "../context/context";
const EditTask = ({title,description,id,setEdit}) => {
    const dispatch = useTaskDispatch();
    const [editedTitle, HandleTitleInputChange, titleReset] = useInputState(title);
    const [editedDescription, HandleDescriptionInputChange, descriptionReset] = useInputState(description);
    return (
        <div>
             <form>
                <label>Title</label>
                <input
                    value={editedTitle}
                    onChange={HandleTitleInputChange}
                    required
                />
                <label>Description</label>
                <textarea 
                    value={editedDescription}
                    onChange={HandleDescriptionInputChange}
                />
                <button
                    type="submit"
                    onClick={(e)=>{
                        e.preventDefault()
                        dispatch({
                            type:'EDIT',
                            editedTitle:editedTitle,
                            editedDescription:editedDescription,
                            id:id
                        })
                        titleReset()
                        descriptionReset()
                       setEdit(false)
            
                    }}
                >Save</button>
            </form>
        </div>
    );
}

export default EditTask;