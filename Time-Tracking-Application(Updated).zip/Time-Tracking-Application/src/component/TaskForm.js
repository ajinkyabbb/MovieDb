import { useTaskDispatch } from "../context/context";
import useInputState from "../hooks/useInputState";


const TaskForm = ({ dispTime,setIsVisible,setTime }) => {
    const dispatch = useTaskDispatch()
    const [title, HandleTitleInputChange, titleReset] = useInputState("");
    const [description, HandleDescriptionInputChange, descriptionReset] = useInputState("");
    return (
        <div>
            <form>
                <label>Title</label>
                <input
                    value={title}
                    onChange={HandleTitleInputChange}
                    required
                />
                <label>Description</label>
                <textarea 
                    value={description}
                    onChange={HandleDescriptionInputChange}
                />
                <button
                    type="submit"
                    onClick={(e)=>{
                        e.preventDefault()
                        dispatch({
                            type:'SAVE',
                            newTitle:title,
                            newDescription:description,
                            newTime: dispTime 
                        })
                        titleReset()
                        descriptionReset()
                        setIsVisible(false)
                        setTime(0)
                    }}
                >Save</button>
                
            </form>
        </div>
    );
}

export default TaskForm;