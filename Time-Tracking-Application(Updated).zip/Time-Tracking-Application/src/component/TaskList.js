import { useState } from "react";
import EditTask from "./EditTask";
const TaskList = ({ task }) => {
    const [isEdit, setEdit] = useState(false)
    return (
        <div>{isEdit ? (
            <div>
                <EditTask title={task.title} description={task.description} id ={task.id} time={task.time} setEdit={setEdit} />


            </div>
        ) : (
            <div>
                <p>Title: {task.title}</p>
                <p>description:  {task.description}</p>
                <p>Time: {task.time}</p>
                <button onClick={()=> setEdit(true)}>Edit </button>
            </div>

        )}


        </div>
    );
}

export default TaskList;