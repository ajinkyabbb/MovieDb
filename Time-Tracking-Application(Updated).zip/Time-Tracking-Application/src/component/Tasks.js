import { useTaskState } from "../context/context";
import TaskList from "./TaskList";


const Task = () => {
    const {tasks} = useTaskState();
    return ( 
        <div>{tasks.map((task)=><TaskList task ={task} key={task.id}/>)} </div>
     );
}
 
export default Task;